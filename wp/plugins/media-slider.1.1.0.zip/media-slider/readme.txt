﻿=== Media Slider - Image Video Carousal Link Slideshow ===
Contributors: awordpresslife
Tags: image slider, responsive slider, video slider, content slider, slider
Donate link: http://awplife.com/
Requires at least: 4.0
Tested up to: 5.3.2
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The Media Slider - Amazing and Easy to use WordPress Slider Plugin. Responsive Image Slider, Video , slider breakpoint, Content Carousal. It is very simple to create slider for your WordPress site.

== Description ==

= Image Slideshow Video Slideshow Carousal Slideshow Link Slideshow Slider =

The Media Slider - Amazing and Easy to use WordPress Slider Plugin. WordPress Media Slider Plugin to Create Image Slider, Content Slider, Video Slideshow with Responsive Design.

It is very simple to create slider for your WordPress site, you can add videos and images, as well as, add a slider to the posts, pages and template files. The slider allows to have unlimited amount of images.

Media slider is the best plugin for show images and video in one slider, then you don”t need two different plugins for images and for videos.

With this WordPress Plugin, you can show your photos and videos more beautifully, because this Media Slider has so many configurations you can set many designs with of your slider with this plugin.

With this plugin you can show titles and descriptions of your images, this plugin also has many settings for title and description, you can also show image thumbnails on slider and thumbnails with description.

It is very easy in use for new and old users, it has more configurations setting you can see below.

https://www.youtube.com/watch?v=2AN-ViMqpDg&list=PLXR1UeeO9dcd7n6lHYgTRCsO7FUoQnIf_

Slider - A Responsive Multimedia Amazing Easy To Use Irresistible CSS & JS Based WordPress Image / Video Slider Plugin. 

It provides a powerful engine for adding images or video slides, with the ability to batch upload, import media data, add/delete/rearrange/sort slides and more. You can publish slider at front-end on the blog post, page and in all widget areas available in the theme.

Create slider from plugin admin dashboard and copy the slider generated shortcode from bottom add image / video button. Embed copied slider shortcode into any blog Page, post, widget area and publish on your blog.

**Upgrade To Premium Plugin - <a href="https://awplife.com/wordpress-plugins/media-slider-premium/">Click Here</a>**

**Check Premium Plugin Demo - <a href="https://awplife.com/demo/media-slider-premium/">Click Here</a>**

**Features**

* Responsive Slider Design
* Customization
* Full-Screen Slider
* Fade Effect
* Video Slider
* Slider Widget
* Slider Navigation
* Slider Thumbnail
* Slider With Breakpoints
* Slider With Text-area
* Slider With Force Size
* Many Customization Settings
* Embed Slider Into any your theme template
* Standard WordPress Import and Export 
* Cross Browser Compatibility

**Support**

It community-driven project that would not be the same without your feedback. If you have any problem or feature request for this plugin, please feel free to <a href="http://awplife.com/contact/">contact us!</a>

**Premium Features**

* Responsive Design
* Custom Width & Height
* Breakpoints
* Auto-play
* Video Supported
* Fade Effect
* 4+ Navigation Styles
* 3+ Image Scale Mode
* 3+ Thumbnail Styles
* 5+ Video Options
* Slider Force Size
* 9+ Slide Text Position
* Slider With Text-area
* Slider Customization Settings
* Slider In Widgets

Slider is fully responsive friendly. All your images will appear as beautiful sliders on your WordPress website. 

== Installation ==

Install Responsive Media Slider either via the WordPress.org plugin directory or by uploading the files to your server.

After activating Media Slider, go to plugin menu.

Click Add Media Slider and upload image slides.

Publish the slider and copy media slider shortcode from the bottom of the slider setting and embed shortcode on any Page/Post/Text Widget.

That's it. You're ready to go!

== Frequently Asked Questions ==

Have any queries?

Please post your question on plugin support forum

https://wordpress.org/support/plugin/media-slider/

== Screenshots ==

1. Slider Preview
2. Slider Preview
3. Slider Preview
4. Slider Preview

= Recommended Plugins =

The following are other recommended plugins by the author:

* [Portfolio Filter Gallery](https://wordpress.org/plugins/portfolio-filter-gallery/ "Best Portfolio Filter Gallery") - The Gallery Plugin to create awesome Portfolio Filter Gallery Plugin in minutes. 

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/portfolio-filter-gallery-premium/">Click Here</a>**

* [Media Slider](https://wordpress.org/plugins/media-slider/ "Best Media Slider") - The Media Slider Plugin to create Media / Video Slider Gallery Plugin in minutes. 

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/media-slider-premium/">Click Here</a>**

* [Best Weather Effect Plugin](https://wordpress.org/plugins/weather-effect/ "Best Weather Effect Plugin") - Very Simple And Easy To Design Your Sites With Multiple Effects.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/weather-effect-premium/">Click Here</a>**

* [Best Grid Gallery Plugin](https://wordpress.org/plugins/new-grid-gallery/ "Best Grid Galley Plugin") - Easy Grid Gallery Widget - Displaying your image in Page & Post widget/sidebar area with very easy.Allows you to customize it to looking exactly what you want.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/grid-gallery-premium/">Click Here</a>**

* [Image Gallery Plugin](https://wordpress.org/plugins/new-image-gallery/ "Image Gallery Plugin") - Gallery Lightbox - Displays all gallery images into the lightbox slider in just a few seconds.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/image-gallery-premium/">Click Here</a>**

* [Photo Gallery Plugin](https://wordpress.org/plugins/new-photo-gallery/ "Image Gallery Plugin") - Displays all  Photo Gallery, Video Gallery, Link Gallery, Map Gallery into Wordpress in just a few seconds.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/photo-gallery-premium/">Click Here</a>**

* [Slider Plugin](https://wordpress.org/plugins/responsive-slider-gallery/ "Slider Plugin") - Fully Responsive Slider Gallery For Wordpress ,You can Show Slider Into Page/Post & Widget/Sidebar By Generate Shortcode.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/responsive-slider-gallery-premium/">Click Here</a>**

* [Contact Form](https://wordpress.org/plugins/new-contact-form-widget/ "Contact Form Plugin") - Contact Form Widget Shortcode Plugin For WordPress.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/contact-form-premium/">Click Here</a>**

* [Social Media Plugin](https://wordpress.org/plugins/new-social-media-widget/ "Social Media") - Display your Social Media Plugin into Widget/Sidebar in WordPress site with very easily.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/social-media-widget-premium//">Click Here</a>**

* [Best Responsive Slider Plugin](https://wordpress.org/plugins/slider-responsive-slideshow/ "Responsive Slider Plugin") - Fully Responsive Light Weight Easy Powerful WordPress Slider Slideshow Plugin.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/slider-responsive-slideshow-premium//">Click Here</a>**

* [Video Gallery Plugin](https://wordpress.org/plugins/new-video-gallery/ "Best Video Gallery Plugin") - The Best Responsive video gallery For Wordpress.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/video-gallery-premium/">Click Here</a>**

* [Facebook Like Share Follow Button](https://wordpress.org/plugins/new-facebook-like-share-follow-button/ "Facebook Like Share Follow Button") - Display your Facebook Like Share Follow Button Plugin into Page/Post & Widget/Sidebar in WordPress sites with very easily.
 
* [Google Plus Badge](https://wordpress.org/plugins/new-google-plus-badge/ "Google Plus Badge") - Google+ Badge & Profile Widget For Show Into Widget & sidebar

* [Facebook Likebox Plugin](https://wordpress.org/plugins/facebook-likebox-widget-and-shortcode/ "Facebook Likebox Plugin") - Facebook Light Box Plugin For Wordpress 

== Changelog ==

= 1.1.0 =

* Enhancements: Tested for wordpress 5.3.2

= 1.0.10 =

* Enhancements: Tested for wordpress 5.2.3

= 1.0.9 =

* Enhancements: Tested for wordpress 5.2.3

= 1.0.8 =
* Enhancements: Tested for wordpress 5.2.2
* Bug Fix: fixed.
* Additional changes: None.

= 1.0.7 =
* Enhancements: Tested for wordpress 5.2.2
* Bug Fix: fixed.
* Additional changes: None.

= 1.0.6 =
* Enhancements: None
* Bug Fix: fixed.
* Additional changes: None.

= 1.0.5 =
* Enhancements: None
* Bug Fix: fixed.
* Additional changes: None.

= 1.0.4 =
* Enhancements: None
* Bug Fix: fixed.
* Additional changes: None.

= 1.0.3 =
* Enhancements: None
* Bug Fix: fixed.
* Additional changes: None.

= 1.0.2 =
* Enhancements: None
* Bug Fix: fixed.
* Additional changes: None.

= 1.0.1 =
* Enhancements: None
* Bug Fix: missing cursor files added into plugin. Video slide icon fixed.
* Additional changes: None.

= 1.0.0 =
* Enhancements: None
* Bug Fix: Yes,
* Additional changes: None.

= 0.4.2 =
* Enhancements: None
* Bug Fix: Yes, Description text updating bug fixed
* Additional changes: None.

= 0.4.1 =
* Enhancements: Yes, Tested for wordpress 5.0.3
* Bug Fix: Yes
* Additional changes: None.

= 0.4.0 =
* Enhancements: Yes, Tested for wordpress 5.0.2
* Bug Fix: Yes
* Additional changes: None.

= 0.3.9 =
* Enhancements: Yes, Tested for wordpress 5.0.1
* Bug Fix: no
* Additional changes: None.

= 0.3.8 =
* Enhancements: Yes, Tested for wordpress 4.9.8
* Bug Fix: no
* Additional changes: custome shortcode copy function added.

= 0.3.7 =
* Enhancements: Yes, Tested for wordpress 4.9.8
* Bug Fix: no
* Additional changes: update links

= 0.3.6 =
* Enhancements: Yes, Tested for wordpress 4.9.8
* Bug Fix: Yes
* Additional changes: No

= 0.3.3 =
* Enhancements: Yes, Tested for wordpress 4.9
* Bug Fix: None
* Additional changes: Yes, Translation Ready

= 0.3.3 =
* Enhancements: Yes, Tested for wordpress 4.9
* Bug Fix: None
* Additional changes: Yes, Added Featured page

= 0.3.2 =
* Enhancements: Yes, Tested for wordpress 4.9
* Bug Fix: None
* Additional changes: Yes, Added theme page

Feature Enhancements: Version 0.3.1
* Enhancements: None
* Bug Fix: bug fixed.
* Additional changes: None

Feature Enhancements: Version 0.3.0
* Enhancements: None
* Bug Fix: bug fixed.
* Additional changes: None

Feature Enhancements: Version 0.2.9
* Enhancements: None
* Bug Fix: yes, link and bug fixed.
* Additional changes: None

Feature Enhancements: Version 0.2.8
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.7
* Enhancements: Tested Upto New version 4.8.1
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.6
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.5
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.4
* Enhancements: New version for wordpress 4.8
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.3
* Enhancements: New version for wordpress 4.8
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.2
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.1
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.0
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.9
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.8
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.7
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.6
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.5
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.4
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.2
* Enhancements: Compatible For New Version
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.0
* Enhancements: Compatible For New Version
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.9
* Enhancements: Compatible For New Version
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.8
* Enhancements: None
* Bug Fix: Description problem resolved.
* Additional changes: None

Feature Enhancements: Version 0.0.7
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.6
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.5
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.4
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.3
* Enhancements: None
* Bug Fix: Textarea Position Problem Fixed.
* Additional changes: None

Feature Enhancements: Version 0.0.2
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.1
* Enhancements: None
* Bug Fix: None
* Additional changes: None

== Upgrade Notice ==
This is an initial release. Start with version 0.0.1 and share your feedback <a href="https://wordpress.org/support/view/plugin-reviews/media-slider//">here</a>.